from django.db import models


class Review(models.Model):
    location = models.ForeignKey('location.Location', on_delete=models.CASCADE)
    user = models.ForeignKey('user.User', on_delete=models.CASCADE)
    rating_clean = models.PositiveIntegerField()
    rating_access = models.PositiveIntegerField()
    rating_other = models.PositiveIntegerField(blank=True, null=True)
    text = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "review"
        unique_together = ('location', 'user')


class Photo(models.Model):
    location = models.ForeignKey('location.Location', on_delete=models.CASCADE)
    review = models.ForeignKey(Review, on_delete=models.CASCADE, blank=True, null=True)
    image = models.ImageField(upload_to='photos/')

    class Meta:
        db_table = "photo"

    @property
    def photo_url(self):
        return self.image.url
    

class PresenceVote(models.Model):
    PRESENCE_CHOICES = [
        ('present', 'Присутствует'),
        ('absent', 'Отсутствует'),
    ]

    location = models.ForeignKey('location.Location', on_delete=models.CASCADE)
    user = models.ForeignKey('user.User', on_delete=models.CASCADE)
    vote = models.CharField(max_length=10, choices=PRESENCE_CHOICES)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "presence_vote"
        unique_together = ('location', 'user')  # один голос на локацию от пользователя

